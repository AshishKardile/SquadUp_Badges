﻿import React from 'react';
import { Badge } from '../types';

interface GymBadgesGridProps {
  badges: Badge[];
  onSelectBadge: (badge: Badge) => void;
}

export const GymBadgesGrid: React.FC<GymBadgesGridProps> = ({ badges, onSelectBadge }) => {
  return (
    <section className="flex flex-col relative">
      {/* Section Header Tab */}
      <div className="self-center bg-[#10223D] border-[3px] border-[#F4C430] rounded-lg px-5 py-1.5 flex items-center gap-2.5 z-10 shadow-[0_4px_0_#000] -mb-4">
        <span className="text-[#F4C430] text-xs">🏅</span>
        <h2 className="font-retro text-xs text-[#FFDF6D] tracking-wide drop-shadow-[1.5px_1.5px_0_#000]">
          GYM BADGES
        </h2>
        <span className="text-[#F4C430] text-xs">🏅</span>
      </div>

      {/* Badge Box */}
      <div
        className="bg-[#FAF4E8] rounded-xl pt-8 px-5 pb-6"
        style={{
          border: '4px solid #10223D',
          boxShadow: '0 6px 0 #000, inset 0 0 0 3px #F4C430',
        }}
      >
        <div className="grid grid-cols-3 sm:grid-cols-6 gap-4">
          {badges.map((badge) => (
            <div
              key={badge.id}
              onClick={() => onSelectBadge(badge)}
              className="flex flex-col items-center cursor-pointer transition-transform hover:-translate-y-1 group"
            >
              {/* Badge Image Container */}
              <div
                className="w-full aspect-square rounded-xl p-1.5 flex items-center justify-center relative overflow-hidden transition-all duration-200"
                style={{
                  background: '#14243B',
                  border: `3px solid ${badge.unlocked ? '#F4C430' : '#2B456E'}`,
                  boxShadow: badge.unlocked
                    ? '0 0 15px rgba(244,196,48,0.4), 0 4px 0 #000'
                    : '0 4px 0 #000',
                }}
              >
                <img
                  src={badge.image}
                  alt={badge.title}
                  className={`w-[90%] h-[90%] object-contain transition-all duration-300 ${
                    badge.unlocked
                      ? 'filter-none opacity-100'
                      : 'grayscale brightness-[0.35] opacity-65'
                  }`}
                />
                {/* Lock icon overlay for locked badges */}
                {!badge.unlocked && (
                  <div className="absolute inset-0 flex items-center justify-center bg-black/20 rounded-xl">
                    <span className="text-[#A0AEC0] text-[16px] drop-shadow-[0_2px_3px_rgba(0,0,0,0.8)]">🔒</span>
                  </div>
                )}
              </div>

              {/* Batch Label */}
              <div
                className={`font-retro text-[8px] px-2 py-0.5 rounded-md mt-2 uppercase text-center w-full truncate ${
                  badge.unlocked
                    ? 'bg-[#E67E22] border border-[#F39C12] text-white'
                    : 'bg-[#10223D] border border-[#2B456E] text-[#A0AEC0]'
                }`}
              >
                {badge.batch}
              </div>

              {/* Unlock Status Dot */}
              <div
                className={`w-5 h-5 rounded-full flex items-center justify-center text-[9px] font-bold mt-1 shadow-md ${
                  badge.unlocked
                    ? 'bg-[#2ECC71] text-white border border-[#27AE60]'
                    : 'bg-[#1F324D] text-[#A0AEC0] border border-[#10223D]'
                }`}
              >
                {badge.unlocked ? '✓' : '?'}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};