import React from 'react';

export interface ToastMessage {
  id: string;
  title: string;
  message: string;
}

interface ToastContainerProps {
  toasts: ToastMessage[];
}

export const ToastContainer: React.FC<ToastContainerProps> = ({ toasts }) => {
  return (
    <div className="fixed top-5 right-5 flex flex-col gap-2.5 z-[300] pointer-events-none">
      {toasts.map((toast) => (
        <div
          key={toast.id}
          className="bg-[#1A202C] text-white border-2 border-[#F4C430] rounded-xl p-3 px-4.5 shadow-[0_6px_20px_rgba(0,0,0,0.6)] flex items-center gap-3 animate-bounce pointer-events-auto"
        >
          <div className="text-2xl">✨</div>
          <div>
            <div className="font-retro text-[10px] text-[#FFDF6D]">{toast.title}</div>
            <div className="font-body text-xs text-[#E2E8F0]">{toast.message}</div>
          </div>
        </div>
      ))}
    </div>
  );
};
