import React from 'react';
import { Badge } from '../types';

interface BadgesEarnedCardProps {
  badges: Badge[];
  activeBadge: Badge;
}

export const BadgesEarnedCard: React.FC<BadgesEarnedCardProps> = ({ badges, activeBadge }) => {
  const unlockedCount = badges.filter(b => b.unlocked).length;
  const progressPercent = (unlockedCount / badges.length) * 100;

  return (
    <section className="bg-[#FAF4E8] border-4 border-[#10223D] rounded-xl p-3.5 px-5 shadow-[0_6px_0_#000,inset_0_0_0_3px_#F4C430] flex items-center gap-5">
      <div className="w-[68px] h-[68px] bg-[#14243B] border-3 border-[#F4C430] rounded-lg flex items-center justify-center shadow-[inset_0_0_12px_rgba(0,0,0,0.6),0_3px_0_#000] relative shrink-0">
        <img
          src={activeBadge.image}
          alt={activeBadge.title}
          className="w-[90%] h-[90%] object-contain"
        />
      </div>

      <div className="grow flex flex-col gap-1.5">
        <div className="font-retro text-[11px] tracking-wide text-[#10223D]">
          BADGES EARNED
        </div>

        <div className="flex items-center gap-4">
          <div className="font-retro text-[26px] text-[#00E5FF] drop-shadow-[2px_2px_0_#10223D] min-w-[70px]">
            <span className="text-[#00E5FF]">{unlockedCount}</span>
            <span className="text-[#10223D] text-[20px]"> / </span>
            <span className="text-[#10223D] text-[24px]">{badges.length}</span>
          </div>

          {/* 6-Block Segmented Progress Bar */}
          <div className="grow h-8 bg-[#0F1D32] border-3 border-[#1B3152] rounded-lg p-1 flex gap-1.5 shadow-[inset_0_3px_6px_rgba(0,0,0,0.8)] relative overflow-hidden">
            {/* Glowing cyan line indicator */}
            <div
              className="absolute bottom-0 left-0 h-[3px] bg-gradient-to-r from-[#00E5FF] to-[#0088FF] shadow-[0_0_10px_#00E5FF] transition-all duration-400"
              style={{ width: `${progressPercent}%` }}
            />

            {badges.map((badge, idx) => (
              <div
                key={badge.id}
                className={`flex-1 h-full rounded transition-all duration-400 relative ${
                  badge.unlocked
                    ? 'bg-gradient-to-b from-[#6CE6FF] via-[#00A3FF] to-[#0066CC] border border-[#80EEFF] shadow-[0_0_12px_rgba(0,200,255,0.8)] opacity-100'
                    : 'bg-gradient-to-b from-[#2D3648] to-[#1A2230] border border-[#3A465C] opacity-80'
                }`}
              >
                {badge.unlocked && (
                  <div className="absolute top-[2px] left-[3px] right-[3px] h-[4px] bg-white/65 rounded-[2px]" />
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
