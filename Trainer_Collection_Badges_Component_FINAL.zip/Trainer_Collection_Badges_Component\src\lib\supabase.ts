import { createClient } from '@supabase/supabase-js';

// Supabase client initialization using environment variables with fallbacks
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://xyzcompany.supabase.co';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.e30.dummyKey';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

/**
 * SQL Database Schema reference for Supabase / PostgreSQL:
 * 
 * -- Profiles Table
 * create table public.profiles (
 *   id uuid references auth.users not null primary key,
 *   username text,
 *   avatar_url text,
 *   xp integer default 0,
 *   level integer default 1,
 *   companion_level integer default 1,
 *   streak_days integer default 1,
 *   quests_completed integer default 0,
 *   created_at timestamp with time zone default timezone('utc'::text, now()) not null
 * );

 * -- User Badges Table
 * create table public.user_badges (
 *   id uuid default gen_random_uuid() primary key,
 *   user_id uuid references public.profiles(id) on delete cascade not null,
 *   badge_id text not null,
 *   unlocked_at timestamp with time zone default timezone('utc'::text, now()) not null,
 *   unique(user_id, badge_id)
 * );

 * -- User Trophies Table
 * create table public.user_trophies (
 *   id uuid default gen_random_uuid() primary key,
 *   user_id uuid references public.profiles(id) on delete cascade not null,
 *   trophy_id text not null,
 *   unlocked_at timestamp with time zone default timezone('utc'::text, now()) not null,
 *   unique(user_id, trophy_id)
 * );
 */
