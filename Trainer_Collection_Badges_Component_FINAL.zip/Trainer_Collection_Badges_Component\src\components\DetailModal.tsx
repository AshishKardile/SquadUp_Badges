﻿import React from 'react';
import { Badge, Trophy } from '../types';

interface DetailModalProps {
  item: Badge | Trophy | null;
  onClose: () => void;
}

export const DetailModal: React.FC<DetailModalProps> = ({ item, onClose }) => {
  if (!item) return null;

  const isBadge = 'batch' in item;
  const title = isBadge ? (item as Badge).title || (item as Badge).batch : (item as Trophy).title;
  const category = isBadge
    ? `🏅 ${(item as Badge).batch}`
    : `🏆 ${(item as Trophy).sub}`;
  const statusLabel = item.unlocked ? 'EARNED' : 'LOCKED';
  const statusColor = item.unlocked
    ? 'bg-[#2ECC71] text-white border border-[#27AE60]'
    : 'bg-[#718096] text-white border border-[#4A5568]';

  return (
    <div
      className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-[200] p-4"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-[420px] rounded-xl overflow-hidden shadow-[8px_8px_0_#000,0_0_0_3px_#8B6914]"
        onClick={(e) => e.stopPropagation()}
        style={{ background: '#F5EDDA', border: '3px solid #8B6914' }}
      >
        {/* Top Header Row: Category + Status Badge */}
        <div className="flex items-center justify-between px-5 pt-4 pb-2">
          <span
            className="font-retro text-[11px] uppercase tracking-widest"
            style={{ color: item.unlocked ? '#2ECC71' : '#718096' }}
          >
            {category}
          </span>
          <span
            className={`font-retro text-[9px] px-2.5 py-0.5 rounded uppercase tracking-wider border ${statusColor}`}
          >
            {statusLabel}
          </span>
        </div>

        {/* Divider */}
        <div className="mx-5 border-t border-[#C9B87A]" />

        {/* Badge / Trophy Image — large & centred */}
        <div className="flex justify-center mt-5 mb-2">
          <div
            className="relative flex items-center justify-center"
            style={{
              width: '200px',
              height: '200px',
              background: '#14243B',
              borderRadius: '16px',
              border: `3px solid ${item.unlocked ? '#F4C430' : '#2B456E'}`,
              boxShadow: item.unlocked
                ? 'inset 0 0 20px rgba(0,0,0,0.6), 0 4px 0 #000, 0 0 28px rgba(244,196,48,0.35)'
                : 'inset 0 0 20px rgba(0,0,0,0.6), 0 4px 0 #000',
            }}
          >
            <img
              src={item.image}
              alt={title}
              style={{
                width: '80%',
                height: '80%',
                objectFit: 'contain',
                filter: item.unlocked ? 'none' : 'grayscale(1) brightness(0.35)',
                opacity: item.unlocked ? 1 : 0.6,
              }}
            />
            {/* Lock overlay */}
            {!item.unlocked && (
              <div className="absolute inset-0 flex items-end justify-center pb-3">
                <span style={{ fontSize: '28px' }}>🔒</span>
              </div>
            )}
            {/* Unlocked / Locked pill at bottom */}
            <div
              className={`absolute -bottom-3.5 left-1/2 -translate-x-1/2 font-retro text-[9px] px-3 py-0.5 rounded border-2 border-white uppercase whitespace-nowrap ${
                item.unlocked ? 'bg-[#2ECC71] text-white' : 'bg-[#718096] text-white'
              }`}
            >
              {item.unlocked ? '✓ UNLOCKED' : '🔒 LOCKED'}
            </div>
          </div>
        </div>

        {/* Title & Description */}
        <div className="px-5 pt-6 pb-1 text-left">
          <h2 className="font-retro text-[15px] text-[#10223D] font-bold leading-tight mb-1">
            {title}
          </h2>
          <p className="font-body text-[12px] text-[#5A4E35] leading-snug mb-3">
            {item.req}
          </p>
        </div>

        {/* Info Box */}
        <div
          className="mx-5 mb-4 rounded-lg overflow-hidden"
          style={{ border: '2px solid #C9B87A', background: '#EDE4CC' }}
        >
          <div className="flex items-start gap-2 px-3 py-2 border-b border-[#C9B87A]">
            <span className="text-[13px] mt-0.5">📋</span>
            <div className="flex flex-col">
              <span className="font-retro text-[8px] text-[#8B6914] uppercase tracking-wider mb-0.5">
                REQUIREMENT
              </span>
              <span className="font-body text-[11px] text-[#10223D] font-semibold leading-snug">
                {item.req}
              </span>
            </div>
          </div>
          <div className="flex items-center gap-2 px-3 py-2">
            <span className="text-[13px]">🕐</span>
            <div className="flex flex-col">
              <span className="font-retro text-[8px] text-[#8B6914] uppercase tracking-wider mb-0.5">
                UNLOCKED DATE
              </span>
              <span className="font-body text-[11px] text-[#10223D] font-semibold">
                {item.unlockedAt || 'Not Yet Earned'}
              </span>
            </div>
          </div>
        </div>

        {/* Close Button */}
        <div className="px-5 pb-5">
          <button
            onClick={onClose}
            className="w-full font-retro text-[11px] text-white uppercase tracking-widest py-3 rounded-lg cursor-pointer transition-all hover:-translate-y-0.5 active:translate-y-0"
            style={{
              background: 'linear-gradient(180deg, #1A7FBE 0%, #0E5F94 60%, #0A4A78 100%)',
              border: '3px solid #0A3A5C',
              boxShadow: '0 5px 0 #082A45, inset 0 1px 0 rgba(255,255,255,0.2)',
            }}
          >
            ✦ CLOSE
          </button>
        </div>
      </div>
    </div>
  );
};