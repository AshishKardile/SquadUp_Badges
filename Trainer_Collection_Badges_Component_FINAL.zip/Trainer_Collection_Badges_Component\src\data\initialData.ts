﻿import { Badge, Trophy, UserProfile, LeaderboardEntry } from '../types';

export const INITIAL_BADGES: Badge[] = [
  {
    id: 'badge_1',
    batch: 'BATCH 01',
    title: 'Thunder Badge',
    req: 'Awarded on successful trainer account login',
    image: '/badges/B1.png',
    unlocked: true,
    element: 'Lightning',
    unlockedAt: 'Default Unlocked'
  },
  {
    id: 'badge_2',
    batch: 'BATCH 02',
    title: 'Flame Badge',
    req: 'Maintain 7-Day Workshop Streak',
    image: '/badges/B2.png',
    unlocked: false,
    element: 'Fire',
    unlockedAt: null
  },
  {
    id: 'badge_3',
    batch: 'BATCH 03',
    title: 'Leaf Badge',
    req: 'Complete 10 Quests',
    image: '/badges/B3.png',
    unlocked: false,
    element: 'Nature',
    unlockedAt: null
  },
  {
    id: 'badge_4',
    batch: 'BATCH 04',
    title: 'Mind Badge',
    req: 'Submit Creative Project',
    image: '/badges/B4.png',
    unlocked: false,
    element: 'Idea',
    unlockedAt: null
  },
  {
    id: 'badge_5',
    batch: 'BATCH 05',
    title: 'Phantom Badge',
    req: 'Defeat Boss Challenge',
    image: '/badges/B5.png',
    unlocked: false,
    element: 'Ghost',
    unlockedAt: null
  },
  {
    id: 'badge_6',
    batch: 'BATCH 06',
    title: 'Dragon Badge',
    req: 'Reach Top 5 Squad Leaderboard',
    image: '/badges/B6.png',
    unlocked: false,
    element: 'Dragon',
    unlockedAt: null
  }
];

export const INITIAL_TROPHIES: Trophy[] = [
  {
    id: 'trophy_1',
    title: 'FIRST STEP',
    sub: 'FIRST EGG',
    req: 'Awarded for attending the first workshop achievement award',
    image: '/trophies/First_Step_1.png',
    unlocked: false,
    unlockedAt: null
  },
  {
    id: 'trophy_2',
    title: 'CONSISTENCY',
    sub: '7-DAY STREAK',
    req: 'Given for excellent attendance throughout the workshop',
    image: '/trophies/Consistency_champ_2.png',
    unlocked: false,
    unlockedAt: null
  },
  {
    id: 'trophy_3',
    title: 'QUEST MASTER',
    sub: 'QUEST MASTERY',
    req: 'Given for completing a large number of quests',
    image: '/trophies/Quest_Mastery_3.png',
    unlocked: false,
    unlockedAt: null
  },
  {
    id: 'trophy_4',
    title: 'STRATEGIST',
    sub: 'CORE SKILLS',
    req: 'Demonstrate deep knowledge in core skills & strategy',
    image: '/trophies/Skill_Mastery_4.png',
    unlocked: false,
    unlockedAt: null
  },
  {
    id: 'trophy_5',
    title: 'TEAM PLAYER',
    sub: 'TEAMWORK',
    req: 'Collaborate with squad members on joint projects',
    image: '/trophies/Team_Player_5.png',
    unlocked: false,
    unlockedAt: null
  },
  {
    id: 'trophy_6',
    title: 'CREATIVE',
    sub: 'DESIGN WORK',
    req: 'Produce an outstanding design or creative submission',
    image: '/trophies/Creative_Trainer_6.png',
    unlocked: false,
    unlockedAt: null
  },
  {
    id: 'trophy_7',
    title: 'TECH TRAINER',
    sub: 'CODING QUEST',
    req: 'Complete all technical coding challenges',
    image: '/trophies/Tech_Trainer_7.png',
    unlocked: false,
    unlockedAt: null
  },
  {
    id: 'trophy_8',
    title: 'CHALLENGER',
    sub: 'BOSS CRUSHER',
    req: 'Conquer the monthly boss battle challenge',
    image: '/trophies/Challange_crusher_8.png',
    unlocked: false,
    unlockedAt: null
  },
  {
    id: 'trophy_9',
    title: 'RISING STAR',
    sub: 'IMPROVEMENT',
    req: 'Show consistent week-over-week performance improvement',
    image: '/trophies/Rising_Star_9.png',
    unlocked: false,
    unlockedAt: null
  },
  {
    id: 'trophy_10',
    title: 'LEGEND',
    sub: 'MASTER TRAINER',
    req: 'Reach level 50 and earn all primary badges',
    image: '/trophies/Master_trainer_10.png',
    unlocked: false,
    unlockedAt: null
  },
  {
    id: 'trophy_11',
    title: 'PROJECT LEAD',
    sub: 'TOP PERFORMER',
    req: 'Lead a squad project to successful deployment',
    image: '/trophies/TOP_performer_11.png',
    unlocked: false,
    unlockedAt: null
  },
  {
    id: 'trophy_12',
    title: 'MENTOR',
    sub: 'COMMUNITY HERO',
    req: 'Assist fellow squad members in community Q&A',
    image: '/trophies/Community_helper_12.png',
    unlocked: false,
    unlockedAt: null
  }
];

export const INITIAL_USER_PROFILE: UserProfile = {
  id: 'user_default',
  username: 'Ashish Kardile',
  xp: 1250,
  level: 5,
  companion_level: 2,
  companion_name: 'Star Companion',
  streak_days: 7,
  quests_completed: 12
};

export const INITIAL_LEADERBOARD: LeaderboardEntry[] = [
  { id: 'l1', username: 'Ashish Kardile', badges_count: 1, trophies_count: 0, xp: 1250, rank: 1 },
  { id: 'l2', username: 'Rohit Bhanose', badges_count: 1, trophies_count: 0, xp: 1100, rank: 2 },
  { id: 'l3', username: 'Squad Leader A', badges_count: 1, trophies_count: 0, xp: 950, rank: 3 },
  { id: 'l4', username: 'Squad Leader B', badges_count: 0, trophies_count: 0, xp: 800, rank: 4 },
  { id: 'l5', username: 'Squad Member C', badges_count: 0, trophies_count: 0, xp: 650, rank: 5 }
];