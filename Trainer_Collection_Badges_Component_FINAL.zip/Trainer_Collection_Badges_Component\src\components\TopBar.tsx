﻿import React from 'react';

export const TopBar: React.FC = () => {
  return (
    <header className="w-[90%] max-w-[900px] flex justify-between items-center mt-4 mb-2 z-10">
      <div className="bg-[#10223D] border-[2.5px] border-[#F4C430] rounded-lg px-3.5 py-1.5 flex items-center gap-2 text-white shadow-pixel">
        <span className="font-retro text-[10px] tracking-widest">
          BADGES &amp; ACHIEVEMENTS COMPONENT
        </span>
      </div>
    </header>
  );
};