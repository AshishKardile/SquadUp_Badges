﻿import React from 'react';
import { Trophy } from '../types';

interface AchievementTrophiesGridProps {
  trophies: Trophy[];
  onSelectTrophy: (trophy: Trophy) => void;
}

export const AchievementTrophiesGrid: React.FC<AchievementTrophiesGridProps> = ({ trophies, onSelectTrophy }) => {
  return (
    <section className="flex flex-col relative">
      {/* Section Header Tab */}
      <div className="self-center bg-[#10223D] border-[3px] border-[#F4C430] rounded-lg px-5 py-1.5 flex items-center gap-2.5 z-10 shadow-[0_4px_0_#000] -mb-4">
        <span className="text-sm">🏆</span>
        <h2 className="font-retro text-xs text-[#FFDF6D] tracking-wide drop-shadow-[1.5px_1.5px_0_#000]">
          ACHIEVEMENT TROPHIES
        </h2>
        <span className="text-sm">🏆</span>
      </div>

      {/* Trophies Box */}
      <div
        className="bg-[#FAF4E8] rounded-xl pt-8 px-5 pb-6"
        style={{
          border: '4px solid #10223D',
          boxShadow: '0 6px 0 #000, inset 0 0 0 3px #F4C430',
        }}
      >
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {trophies.map((trophy) => (
            <div
              key={trophy.id}
              onClick={() => onSelectTrophy(trophy)}
              className="flex flex-col items-center cursor-pointer transition-all duration-200 hover:-translate-y-1 rounded-xl p-2.5 relative"
              style={{
                background: '#14243B',
                border: `3px solid ${trophy.unlocked ? '#F4C430' : '#2B456E'}`,
                boxShadow: trophy.unlocked
                  ? '0 0 12px rgba(244,196,48,0.3), 0 4px 0 #000'
                  : '0 4px 0 #000',
                minHeight: '148px',
              }}
            >
              {/* Trophy Image */}
              <div className="w-full h-[75px] flex items-center justify-center relative mb-1">
                <img
                  src={trophy.image}
                  alt={trophy.title}
                  className={`max-w-[88%] max-h-[88%] object-contain transition-all duration-300 ${
                    trophy.unlocked
                      ? 'filter-none drop-shadow-[0_0_6px_rgba(255,223,109,0.5)]'
                      : 'grayscale brightness-[0.35] opacity-60'
                  }`}
                />
                {/* Lock overlay */}
                {!trophy.unlocked && (
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="text-[#6B7A99] text-[14px] drop-shadow-[0_2px_3px_rgba(0,0,0,0.9)]">🔒</span>
                  </div>
                )}
              </div>

              {/* Trophy Title Bar */}
              <div
                className="w-full rounded-md py-1 px-1 text-center font-retro text-[9px] uppercase truncate"
                style={{
                  background: trophy.unlocked ? '#10223D' : '#0F1D32',
                  border: `1px solid ${trophy.unlocked ? '#F4C430' : '#2B456E'}`,
                  color: '#ffffff',
                  textShadow: '1px 1px 0 #000',
                }}
              >
                {trophy.title}
              </div>

              {/* Sub Label */}
              <div
                className="font-retro text-[7px] mt-1 text-center uppercase"
                style={{ color: trophy.unlocked ? '#FFDF6D' : '#87CEEB' }}
              >
                {trophy.sub}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};