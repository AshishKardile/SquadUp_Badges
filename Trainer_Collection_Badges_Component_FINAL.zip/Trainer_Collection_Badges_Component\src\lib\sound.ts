// Web Audio API Chiptune BGM & Unlock Fanfare Synthesizer

let audioCtx: AudioContext | null = null;
let bgmInterval: number | null = null;
let isBGMPlaying = false;

function getAudioContext(): AudioContext {
  if (!audioCtx) {
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    audioCtx = new AudioContextClass();
  }
  if (audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
  return audioCtx;
}

export function playNote(freq: number, duration: number, type: OscillatorType = 'square', gainVal = 0.08) {
  try {
    const ctx = getAudioContext();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    
    osc.type = type;
    osc.frequency.setValueAtTime(freq, ctx.currentTime);
    
    gain.gain.setValueAtTime(gainVal, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);
    
    osc.connect(gain);
    gain.connect(ctx.destination);
    
    osc.start();
    osc.stop(ctx.currentTime + duration);
  } catch {
    // Ignore audio autoplay policies if suspended
  }
}

export function playUnlockFanfare() {
  const notes = [
    { f: 523.25, d: 0.1 }, // C5
    { f: 659.25, d: 0.1 }, // E5
    { f: 783.99, d: 0.1 }, // G5
    { f: 1046.50, d: 0.3 } // C6
  ];
  
  notes.forEach((note, idx) => {
    setTimeout(() => {
      playNote(note.f, note.d, 'square', 0.12);
    }, idx * 100);
  });
}

export function startBGM(): boolean {
  if (isBGMPlaying) return true;
  isBGMPlaying = true;
  
  const melody = [261.63, 329.63, 392.00, 523.25, 392.00, 329.63];
  let noteIndex = 0;
  
  bgmInterval = window.setInterval(() => {
    if (!isBGMPlaying) return;
    playNote(melody[noteIndex], 0.15, 'triangle', 0.04);
    noteIndex = (noteIndex + 1) % melody.length;
  }, 300);
  
  return true;
}

export function stopBGM(): boolean {
  isBGMPlaying = false;
  if (bgmInterval !== null) {
    clearInterval(bgmInterval);
    bgmInterval = null;
  }
  return false;
}

export function toggleBGMState(): boolean {
  if (isBGMPlaying) {
    return stopBGM();
  } else {
    return startBGM();
  }
}
