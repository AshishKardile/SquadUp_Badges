﻿import React from 'react';

export const HeaderBanner: React.FC = () => {
  return (
    <div className="flex justify-center -mb-2.5">
      <img
        src="/ui/header_banner_transparent.png"
        alt="Trainer Collection - Your Levelup Achievement Journey"
        className="max-w-full h-auto drop-shadow-[0_6px_0_#000]"
      />
    </div>
  );
};