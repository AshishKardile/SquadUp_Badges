﻿import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import { Badge, Trophy } from './types';
import { INITIAL_BADGES, INITIAL_TROPHIES } from './data/initialData';
import { playUnlockFanfare } from './lib/sound';

import { HeaderBanner } from './components/HeaderBanner';
import { GymBadgesGrid } from './components/GymBadgesGrid';
import { AchievementTrophiesGrid } from './components/AchievementTrophiesGrid';
import { DetailModal } from './components/DetailModal';
import { ToastContainer, ToastMessage } from './components/ToastContainer';

export const App: React.FC = () => {
  const [badges, setBadges] = useState<Badge[]>(INITIAL_BADGES);
  const [trophies, setTrophies] = useState<Trophy[]>(INITIAL_TROPHIES);
  const [selectedItem, setSelectedItem] = useState<Badge | Trophy | null>(null);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const showToast = (title: string, message: string) => {
    const newToast: ToastMessage = {
      id: Date.now().toString(),
      title,
      message,
    };
    setToasts(prev => [...prev, newToast]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== newToast.id));
    }, 3500);
  };

  const triggerConfettiAnimation = () => {
    confetti({
      particleCount: 70,
      spread: 60,
      origin: { y: 0.6 }
    });
  };

  // Programmatic API exposed on window.TrainerAchievements
  useEffect(() => {
    (window as unknown as Record<string, unknown>).TrainerAchievements = {
      unlockBadge: (id: string) => {
        setBadges(prev =>
          prev.map(b => {
            if ((b.id === id || b.batch.toLowerCase() === id.toLowerCase()) && !b.unlocked) {
              playUnlockFanfare();
              triggerConfettiAnimation();
              showToast('BADGE UNLOCKED!', `${b.batch} (${b.title}) unlocked!`);
              return { ...b, unlocked: true, unlockedAt: new Date().toLocaleDateString() };
            }
            return b;
          })
        );
      },
      lockBadge: (id: string) => {
        setBadges(prev =>
          prev.map(b => (b.id === id || b.batch.toLowerCase() === id.toLowerCase() ? { ...b, unlocked: false, unlockedAt: null } : b))
        );
      },
      unlockTrophy: (id: string) => {
        setTrophies(prev =>
          prev.map(t => {
            if ((t.id === id || t.title.toLowerCase() === id.toLowerCase()) && !t.unlocked) {
              playUnlockFanfare();
              triggerConfettiAnimation();
              showToast('TROPHY UNLOCKED!', `${t.title} trophy unlocked!`);
              return { ...t, unlocked: true, unlockedAt: new Date().toLocaleDateString() };
            }
            return t;
          })
        );
      },
      lockTrophy: (id: string) => {
        setTrophies(prev =>
          prev.map(t => (t.id === id || t.title.toLowerCase() === id.toLowerCase() ? { ...t, unlocked: false, unlockedAt: null } : t))
        );
      },
      getState: () => ({ badges, trophies })
    };
  }, [badges, trophies]);

  return (
    <div className="min-h-screen bg-[#0d1b2a] flex flex-col items-center pb-16 relative overflow-x-hidden">
      {/* 16-bit Pixel Scenery Background */}
      <div className="bg-scenery" />
      <div className="fixed inset-0 bg-black/15 pointer-events-none z-[1]" />

      <main className="w-[94%] max-w-[760px] mt-4 flex flex-col gap-4 z-10">
        <HeaderBanner />

        <GymBadgesGrid
          badges={badges}
          onSelectBadge={(badge) => setSelectedItem(badge)}
        />

        <AchievementTrophiesGrid
          trophies={trophies}
          onSelectTrophy={(trophy) => setSelectedItem(trophy)}
        />
      </main>

      <DetailModal item={selectedItem} onClose={() => setSelectedItem(null)} />

      <ToastContainer toasts={toasts} />
    </div>
  );
};