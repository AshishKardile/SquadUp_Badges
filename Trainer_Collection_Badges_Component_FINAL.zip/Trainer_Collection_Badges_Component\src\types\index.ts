// Data models matching the Tech Stack specification

export interface Badge {
  id: string;
  batch: string;
  title: string;
  req: string;
  image: string;
  unlocked: boolean;
  element: string;
  unlockedAt?: string | null;
}

export interface Trophy {
  id: string;
  title: string;
  sub: string;
  req: string;
  image: string;
  unlocked: boolean;
  unlockedAt?: string | null;
}

export interface UserProfile {
  id: string;
  username: string;
  avatar_url?: string;
  xp: number;
  level: number;
  companion_level: number;
  companion_name: string;
  streak_days: number;
  quests_completed: number;
}

export interface LeaderboardEntry {
  id: string;
  username: string;
  avatar_url?: string;
  badges_count: number;
  trophies_count: number;
  xp: number;
  rank: number;
}
